$('#start-button').click(function(e) {
    e.preventDefault();
    $('#dauntless-carousel').carousel('cycle'); 
 });   